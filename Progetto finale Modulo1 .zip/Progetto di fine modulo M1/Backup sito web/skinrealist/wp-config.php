<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/documentation/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'skinrealist' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'xmm}6V1!MAP{t7L~[yuuP=S/+ps;0^Wss8}hI7> w&TyU;: >IDHaCr_td#59rQ,' );
define( 'SECURE_AUTH_KEY',  'r _{wZ<iYXEaE+Jo$DkBPh|JJ:AJe&|wkMwP4laF1JF^pf}y$#.]czbJ &/mfrx$' );
define( 'LOGGED_IN_KEY',    '4Jv0U+JaE0dQ*f.~E~TKK[mXB$mw<2U~6>$*@os,,202JN=t(X]c.LD}!8bTW5QD' );
define( 'NONCE_KEY',        'F9d-:fNrq!0IZ<OozVHGq0lI:(ilQPz.IH>QYUL(-2>vgj ~8s&O7HM0r/J[:HFU' );
define( 'AUTH_SALT',        'P/#9aEB}EwJl}/Fl=x> o|#5)1T{tf2[r4}p~xpH)U}+fmh>UkHf=QA JEj8y?90' );
define( 'SECURE_AUTH_SALT', '(2axE{Jai>D!uy[a>3sSUv{e_7&De/Gye/FEiOnsEaTmtC=%Sm6}wOV_W7B|*rrr' );
define( 'LOGGED_IN_SALT',   'B-Osv,shq}0qe.(.ft1vF[d9}R;vC(L4D8t|Cyy_)f<3s.!R8?+V^5rDy~&wAjWC' );
define( 'NONCE_SALT',       'Jxo^:XGo}hir@>,F8>**OOQuicc$5(05C!++nY;lvyo$kPhw43W2eZyj{wM!~.| ' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'sr_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/documentation/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
